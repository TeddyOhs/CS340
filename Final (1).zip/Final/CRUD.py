from pymongo import MongoClient
import pandas as pd

class MongoDB_CRUD:
    def __init__(self, username, password, host='nv-desktop-services.apporto.com', port=30205):
        self.client = MongoClient(host, port, username=username, password=password)

    def create(self, AAC, animals, document):
        try:
            db = self.client[AAC]
            collection = db[animals]
            result = collection.insert_one(document)
            return True if result.inserted_id else False
        except Exception as e:
            print(f"Error in create operation: {e}")
            return False

    def read(self, AAC, animals, query={}):
        try:
            db = self.client[AAC]
            collection = db[animals]
            result = collection.find(query)
            return list(result)
        except Exception as e:
            print(f"Error in read operation: {e}")
            return []
            
    def read_all(self, AAC, animals):
        try:
            db = self.client[AAC]
            collection = db[animals]
            result = collection.find({})
            return list(result)
        except Exception as e:
            print(f"Error in read_all operation: {e}")
            return []

    def update(self, AAC, animals, query, update_data):
        try:
            db = self.client[AAC]
            collection = db[animals]
            result = collection.update_many(query, {'$set': update_data})
            return result.modified_count
        except Exception as e:
            print(f"Error in update operation: {e}")
            return 0

    def delete(self, AAC, animals, query):
        try:
            db = self.client[AAC]
            collection = db[animals]
            result = collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error in delete operation: {e}")
            return 0

username = "aacuser"
password = "SNHU1234"
shelter = MongoDB_CRUD(username, password)

# Retrieve data from MongoDB
df = pd.DataFrame.from_records(shelter.read_all('AAC', 'animals'))

# Drop '_id' column
df.drop(columns=['_id'], inplace=True)

